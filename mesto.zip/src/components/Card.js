// Добавление карточек, удаление, лайк, открытие карточек
class Card {
    constructor(config, item, template, openViewPopup, userID, { submitHandlerCardDelete, likes }) {
        this._item = item,
            this._config = config,
            this._view = template.querySelector('.element').cloneNode(true),
            this._cardImage = this._view.querySelector('.element__image'),
            this._cardTitle = this._view.querySelector('.element__title'),
            this._openPopup = openViewPopup,
            this._userID = userID,
            this._delButton = this._view.querySelector('.element__delete'),
            this._submitHandlerCardDelete = submitHandlerCardDelete,
            this._likes = likes,
            this._elementLikeBtn = this._view.querySelector('.element__btn'),
            this._popupDeleteBtn = document.querySelector('.popup__delete-btn-close'),
            this._handleCardClick = this._handleCardClick.bind(this)
    }

    generateCard() {
        this._cardImage.src = this._item.link;
        this._cardImage.alt = this._item.name;
        this._cardTitle.textContent = this._item.name;
        if (this._userID === this._item.owner._id) {
            this._delButton;
        } else {
            this._delButton.remove();
        }
        this._setEventListeners();
        return this._view;
    }

    _handleCardClick() {
        this._openPopup(this._item.name, this._item.link);
    }

    _like(evt) {
        evt.target.classList.toggle('element__btn_like_active');
    }

    isLiked() {
        return (this._likes.some(user => user._id === this._userID));
    }

    setLikes(data) {
        this._likes = data;
        this._updateLikes();
    }

    _updateLikes() {
        if (this.isLiked()) {
            this._elementLikeBtn.classList.remove('element__btn_like_active');
        } else {
            this._elementLikeBtn.classList.add('element__btn_like_active');
        }
    }

    removeCard() {
        this._view.remove();
    }

    _setEventListeners() {
        this._delButton.addEventListener('click', () => {
            this._submitHandlerCardDelete(this);
        });
        this._view.querySelector('.element__btn').addEventListener('click', (evt) => {
            this._like(evt);
        });
        this._cardImage.addEventListener('click', this._handleCardClick);
    }
}

export default Card;