import Popup from "./Popup";
// import PopupWithForm from "./PopupWithForm";

// class PopupWithDelete extends PopupWithForm {
//     constructor(popupSelector, formDelete, { deleteCard }) {
//         super(config, popupSelector, { formSubmit }, retreiveData = null),
//             this._popupDeleteBtn = formDelete,
//             this._deleteCard = deleteCard
//     }

//     setSubmit() {
//         this._popupDeleteBtn.addEventListener('submit', () => this._deleteCard(this));
//     }
// }
class PopupWithDelete extends Popup {
    constructor(popupSelector, formDeleteCard, { submitHandlerCardDelete }) {
        super(popupSelector),
            this._popupDeleteBtn = formDeleteCard,
            this._submitHandlerCardDelete = submitHandlerCardDelete
    }

    setSubmit() {
        this._popupDeleteBtn.addEventListener('submit', () => {
            this._submitHandlerCardDelete(this);
        });
        console.dir("_submitHandlerCardDelete2", this._submitHandlerCardDelete)
    }
}

export default PopupWithDelete;